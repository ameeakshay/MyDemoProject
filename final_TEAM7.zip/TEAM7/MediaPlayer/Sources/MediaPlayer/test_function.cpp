#include "categories.h"
#include "mediaplayer.h"
#include<QDir>
#include<QDebug>
#include<QMediaPlayer>
#include<QMediaPlaylist>
#include<fstream>
#include<iostream>
#include "string"
#include<QHash>
#include <QMultiHash>

bool tclCategories::bTestCategories()
{
    QStringList sTrackList;
    bool result=false;

    // Test bGetFileNameFromDir
    result=bGetFileNameFromDir(m_sMusicDirPath,oAllTracks);

    // Test rGetMetaDataFromFile
    QString sFile;
    trMetaData data;

    foreach(sFile,oAllTracks)
    {
       data = rGetMetaDataFromFile(sFile);
        qDebug()<<data.sAlbum;
        qDebug()<<data.sArtist;
    }

    // Test bPopulateAllTracksAndCategories
    result=bPopulateAllTracksAndCategories();

    // Test sGetAllTracks and related functions
    QStringList sAllsongs= sGetAllTracks();
    qDebug() << "All track List\n" << sAllsongs;

    QStringList sArtists= sGetArtistNames();
    qDebug() << "Artist List\n" << sArtists;


    QStringList sAlbums= sGetAlbumNames();
    qDebug() << "Album List\n" << sAlbums;

    // Test get tracks from category item
    QString sArtistName = "Siddharth Menon";
    sTrackList = sGetTracksForArtist(sArtistName);
    if (!sTrackList.isEmpty())
    {
        qDebug() << "Track list for " << sArtistName << endl << sTrackList;
    }
    else
    {
        qDebug() << "No Tracks found for " << sArtistName;
    }

    QString sAlbumName = "Chennai Express";
    sTrackList = sGetTracksForAlbum(sAlbumName);
    if (!sTrackList.isEmpty())
    {
        qDebug() << "Track list for " << sAlbumName << endl << sTrackList;
    }
    else
    {
        qDebug() << "No Tracks found for " << sAlbumName;
    }

    return result;

}

bool tclMediaPlayer::bTestMediaPlayer()
{

    bool result = vAddTrackPlayList();

    bInitMediaPlayer();
    //qDebug()<< m_oCategory.sGetAllTracks();

    return result;
}
