#include <QtGui/QApplication>
#include "applicationui.h"
#include "mediaplayer.h"
#include <QDebug>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    tclApplicationUI w;
    w.show();
    qDebug()<<"Hello";
    return a.exec();
}
