#include "applicationui.h"
#include "ui_applicationui.h"
#include <qtimer.h>
#include "mediaplayer.h"
#include <QTextStream>
    tclApplicationUI::tclApplicationUI(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::tclApplicationUI)
{

    ui->setupUi(this);
    ui->shuffle->setCheckable(true);
    ui->play->setCheckable(true);
    ui->mute->setCheckable(true);
    ui->TTS->setCheckable(true);
    eStatus = tclMediaPlayer::eRepeatOFF;
    bState = false;
    bSongClicked = false;
    ui->timer->setMinimum(1);
    ui->timer->setMaximum(120);
    ui->timer->setSingleStep(5);
    m_tclPlayer = new tclMediaPlayer;
    bState = m_tclPlayer->bTestMediaPlayer();
    QStringList sAllSongs = m_tclPlayer->sSelectAllSongs();
    m_tclPlayer->vLoadPlayList( sAllSongs);
    ui->playlistWidget->addItems(sAllSongs);
    vDispTrack();
    eListState = allSongs;
    ui->volumebar->setValue(40);
    m_tclPlayer->vSetVolume(40);

    //Check for em_tclPlayerty directory
    if(!bState)
    {
        QMessageBox *oMsgbox = new QMessageBox;
        oMsgbox->setText("The Directory is Em_tclPlayerty");
        oMsgbox->exec();
    }

    // Create timer
    m_qTimer = new QTimer(this);

    connect(m_tclPlayer->m_QPlayer,SIGNAL(positionChanged(qint64)),this,SLOT(onpostionchanged(qint64)));
    connect(m_tclPlayer->m_QPlayer,SIGNAL(durationChanged(qint64)),this,SLOT(ondurationchanged(qint64)));
    connect(ui->seekbar,SIGNAL(sliderMoved(int)),this,SLOT(onseekbarMoved(int)));
    connect(m_tclPlayer->m_QMediaPlayList,SIGNAL(currentMediaChanged(QMediaContent)),this,SLOT(onMediaContentChanged()));
    connect(m_qTimer, SIGNAL(timeout()), this, SLOT(onClose()));
    connect(m_qTimer, SIGNAL(timeout()), this, SLOT(onTimeOut()));
}
void tclApplicationUI::closeEvent(QCloseEvent *event)
{
QMessageBox::StandardButton dialog;
dialog = QMessageBox::warning(this, "exit",
"Do you want to exit the player?",
QMessageBox::Yes| QMessageBox::No);
if( dialog == QMessageBox::Yes)
{
    ui->mute->setChecked(false);
    exit(0);
}
else
    event->ignore();

}
tclApplicationUI::~tclApplicationUI()
{

    delete ui;
}


void tclApplicationUI::on_play_toggled(bool checked)
{
    checked = ui->play->isChecked();
    ui->play->setChecked(checked);
    //qDebug() << checked;
    m_tclPlayer->vSetPlayState();
    ui->playlistWidget->setCurrentRow(m_tclPlayer->m_QMediaPlayList->currentIndex());
    vDispTrack();
    vConnectSignalsSlots();
}


void tclApplicationUI::on_shuffle_toggled(bool checked)
{
    bState = checked;
    checked = ui->shuffle->isChecked();
    ui->shuffle->setChecked(checked);
    //qDebug() << checked;
    if(checked == true && eStatus == tclMediaPlayer::eRepeatOne)
    {
        ui->repeat->setIcon(QIcon(":/images/repeatff.png"));
        eStatus = tclMediaPlayer::eRepeatOFF;
    }
    m_tclPlayer->vSetShuffleMode();

}

void tclApplicationUI::on_mute_toggled(bool checked)
{

    checked = ui->mute->isChecked();
    ui->mute->setChecked(checked);
    //qDebug() << checked;
    m_tclPlayer->vSetMute();
}

void tclApplicationUI::on_repeat_clicked()
{
    switch(eStatus)
    {
    case tclMediaPlayer::eRepeatOFF:
        if(bState == true)
            ui->shuffle->setChecked(false);
        ui->repeat->setIcon(QIcon(":/images/rep 1.png"));
        eStatus = tclMediaPlayer::eRepeatOne;
        m_tclPlayer->vSetRepeatMode(eStatus);

        break;
    case tclMediaPlayer::eRepeatOne:
        ui->repeat->setIcon(QIcon(":/images/repeat t.png"));
        eStatus = tclMediaPlayer::eRepeatAll;
        m_tclPlayer->vSetRepeatMode(eStatus);
        break;
    case tclMediaPlayer::eRepeatAll:
        ui->repeat->setIcon(QIcon(":/images/repeat_off t.png"));
        eStatus = tclMediaPlayer::eRepeatOFF;
        m_tclPlayer->vSetRepeatMode(eStatus);
        break;
    }

}

void tclApplicationUI::on_info_pressed()
{
    QMessageBox *oMsgbox = new QMessageBox;
    oMsgbox->setText("MuFAQ. MediaPlayer \n Developed By - Team 7 \n Developers : \n Akshay Trivedi \n Nilay Gupta \n Anushree A B \n Sreelekshmi GopaKumar \n Sharath S B ");

    oMsgbox->exec();
}

void tclApplicationUI::on_volumebar_valueChanged(int value)
{
    ui->mute->setChecked(false);
    m_tclPlayer->vSetVolume(value);
    //qDebug() << value;
}

void tclApplicationUI::on_stop_clicked()
{
    ui->play->setChecked(false);
    m_tclPlayer->vStopTrack();
}

void tclApplicationUI::on_next_clicked()
{
    if(eStatus == tclMediaPlayer::eRepeatOFF)
    {
        if(m_tclPlayer->m_QMediaPlayList->currentIndex() == (m_tclPlayer->m_QMediaPlayList->mediaCount() - 1))
        {
            ui->play->setChecked(false);
            m_tclPlayer->m_QPlayer->stop();
        }
    }
    else
    {
        m_tclPlayer->vNextTrack();
        ui->seekbar->setValue(0);
        if(eListState == allSongs || eListState == allArtistSongs || eListState == allAlbumSongs)
        {
            if(bSongClicked == false)
                ui->playlistWidget->setCurrentRow(m_tclPlayer->m_QMediaPlayList->currentIndex());
        }
        vDispTrack();
    }
}

void tclApplicationUI::on_prev_clicked()
{
    if(eStatus == tclMediaPlayer::eRepeatOFF)
    {
        if(m_tclPlayer->m_QMediaPlayList->currentIndex() == 0)
        {
            ui->play->setChecked(false);
            m_tclPlayer->m_QPlayer->stop();
        }
    }
    else
    {
        m_tclPlayer->vPreviousTrack();
        ui->seekbar->setValue(0);
        if(eListState == allSongs || eListState == allArtistSongs || eListState == allAlbumSongs)
        {
            if(bSongClicked == false)
                ui->playlistWidget->setCurrentRow(m_tclPlayer->m_QMediaPlayList->currentIndex());
        }
        vDispTrack();
    }
}

void tclApplicationUI::on_TTS_toggled(bool checked)
{
    QString sValue;
    QMessageBox *oMsgbox = new QMessageBox;
    int arg1;
    checked = ui->TTS->isChecked();
    ui->TTS->setChecked(checked);
    qDebug() << checked;
    if(checked == true) // Enable timer
    {
        arg1 = ui->timer->value();
        qDebug() << arg1;

        m_qTimer->setInterval(arg1*10*1000);
        m_qTimer->setSingleShot(true);
        m_qTimer->start();

        QTextStream TextStream(&sValue);
        TextStream << arg1;
        oMsgbox->setText("The timer has been set to " + sValue  + " minutes.");
        oMsgbox->exec();
    }
    else // Disable timer
    {
        m_qTimer->setSingleShot(false);
        m_qTimer->stop();
        oMsgbox->setText("The timer has been turned off.");
        oMsgbox->exec();
    }
}

void tclApplicationUI::on_timer_valueChanged(int arg1)
{
    ui->timer->setWrapping(true);
    ui->timer->setSuffix(" mins");

}

void tclApplicationUI::on_seekbar_valueChanged(qint64 value)
{
    value = m_tclPlayer->m_QPlayer->duration();
    qDebug() << value;
    if(value >= m_nTotalTrackTime)
    {
        ui->seekbar->setDisabled(true);
        m_tclPlayer->vNextTrack();
        ui->seekbar->setEnabled(true);
    }
}

void tclApplicationUI::on_AllSongsListButton_clicked()
{
    ui->playlistWidget->clear();
    QStringList sAllSongs = m_tclPlayer->sSelectAllSongs();
    ui->playlistWidget->addItems(sAllSongs);
    m_tclPlayer->vLoadPlayList(sAllSongs);
    qDebug() << "songs loaded";
    m_tclPlayer->m_QMediaPlayList->setCurrentIndex(0);
    ui->playlistWidget->setCurrentRow(m_tclPlayer->m_QMediaPlayList->currentIndex());
    vDispTrack();
    if(ui->play->isChecked())
    {
        qDebug() << ui->play->isChecked() << "State of play now";
       ui->play->setChecked(false);
    }
    else
       m_tclPlayer->vStopTrack();
    ui->play->setChecked(true);
    eListState = allSongs;
}

void tclApplicationUI::on_AlbumButton_clicked()
{
    eListState = albums;
    ui->playlistWidget->clear();
    QStringList sAlbums = m_tclPlayer->sSelectAlbum();
    ui->playlistWidget->addItems(sAlbums);
    bSongClicked = true;
}

void tclApplicationUI::on_ArtistButton_clicked()
{
    eListState = artists;
    ui->playlistWidget->clear();
    QStringList sArtists = m_tclPlayer->sSelectArtist();
    ui->playlistWidget->addItems(sArtists);
    bSongClicked = true;
}




void tclApplicationUI::on_playlistWidget_itemClicked(QListWidgetItem *item)
{
    int currentRow;
    QString sCurItem;
    QStringList sCurSongs;
    item = ui->playlistWidget->currentItem();
    sCurItem = item->text();
    if(eListState == albums)
    {

        ui->playlistWidget->clear();
        sCurSongs = m_tclPlayer->sSelectAlbumItem(sCurItem);
        m_album = sCurItem;
        ui->playlistWidget->addItems(sCurSongs);
        //vDispTrack();
        eListState = allAlbumSongs;
    }
    else if(eListState == artists)
    {
        ui->playlistWidget->clear();
        sCurSongs = m_tclPlayer->sSelectArtistItem(sCurItem);
        m_artist = sCurItem;
        ui->playlistWidget->addItems(sCurSongs);
        //vDispTrack();
        eListState = allArtistSongs;
    }
    else if(eListState == allSongs)
    {
        QStringList qsAllSongs;
        currentRow = ui->playlistWidget->currentRow();
        qsAllSongs= m_tclPlayer->sSelectAllSongs();
        m_tclPlayer->vLoadPlayList( qsAllSongs);
        m_tclPlayer->vSelectTrack(currentRow);
        ui->play->setChecked(true);
    }
    else if(eListState == allAlbumSongs)
    {
        bSongClicked = false;
        currentRow = ui->playlistWidget->currentRow();
        sCurSongs = m_tclPlayer->sSelectAlbumItem(m_album);
        m_tclPlayer->vLoadPlayList(sCurSongs);
        m_tclPlayer->vSelectTrack(currentRow);
        vDispTrack();
        ui->play->setChecked(true);
    }
    else if(eListState == allArtistSongs)
    {
        bSongClicked = false;
        currentRow = ui->playlistWidget->currentRow();
        sCurSongs = m_tclPlayer->sSelectArtistItem(m_artist);
        m_tclPlayer->vLoadPlayList(sCurSongs);
        m_tclPlayer->vSelectTrack(currentRow);
        vDispTrack();
        ui->play->setChecked(true);
    }

}

void tclApplicationUI::ondurationchanged(qint64 position)
{
    ui->seekbar->setMaximum(position);
    ui->seekbar->setMinimum(0);
    int seconds = (position/1000) % 60;
    int minutes = (position/60000) % 60;
    m_nTotalTrackTime = position;
    QString sValue;
    QTextStream TextStream(&sValue);
    TextStream << minutes << " : " << seconds;
    ui->TotalTrackTime->setText(sValue);
}

void tclApplicationUI::onpostionchanged(qint64 position)
{
    ui->seekbar->setValue(position);
    int seconds = (position/1000) % 60;
    int minutes = (position/60000) % 60;

    QString sValue;
    QTextStream TextStream(&sValue);
    TextStream << minutes << " : " << seconds;
    ui->curTrackTime->setText(sValue);

}




void tclApplicationUI::onseekbarMoved(int position)
{
    m_tclPlayer->m_QPlayer->setPosition(position);
    if(position >= m_nTotalTrackTime)
    {
        ui->seekbar->setDisabled(true);
        m_tclPlayer->vNextTrack();
        ui->seekbar->setEnabled(true);
    }
}

void tclApplicationUI::onClose()
{
    ui->play->setChecked(false);
    m_tclPlayer->vStopTrack();
    QWidget::close();
}

void tclApplicationUI::vDispTrack()
{
    QString sValue1, sValue2;
    QTextStream oval1(&sValue1);
    QTextStream oval2(&sValue2);

    m_nCurrentTrackIndex = m_tclPlayer->m_QMediaPlayList->currentIndex() + 1;
    m_nTotalTracks = m_tclPlayer->m_QMediaPlayList->mediaCount();
    oval1 << m_nCurrentTrackIndex;
    ui->curTrackCount->setText(sValue1);
    oval2 << m_nTotalTracks;
    ui->TotalTrackCount->setText(sValue2);
}

void tclApplicationUI::onMediaContentChanged()
{
    if(eListState == allSongs || eListState == allAlbumSongs || eListState == allArtistSongs)
    {
        if(bSongClicked == false)
        {
            ui->playlistWidget->setCurrentRow(m_tclPlayer->m_QMediaPlayList->currentIndex());
            vDispTrack();
        }
    }
}


trMetaData tclApplicationUI::rLoadMetaData()
{
    trMetaData m_rTrackData;
        m_rTrackData.sTitle = m_tclPlayer->m_QPlayer->metaData(QtMultimediaKit::Title).toString();
        m_rTrackData.sAlbum = m_tclPlayer->m_QPlayer->metaData(QtMultimediaKit::AlbumTitle).toString();
        m_rTrackData.sArtist = m_tclPlayer->m_QPlayer->metaData(QtMultimediaKit::AlbumArtist).toString();

        if(m_rTrackData.sArtist.isEmpty()||m_rTrackData.sArtist.isNull())
        {
             m_rTrackData.sArtist="Unknown";
        }

        if(m_rTrackData.sAlbum.isEmpty()||m_rTrackData.sAlbum.isNull())
        {
             m_rTrackData.sAlbum="Unknown";
        }

        if(m_rTrackData.sTitle.isEmpty()||m_rTrackData.sTitle.isNull())
        {
            QString sFullPath = m_tclPlayer->m_QMediaPlayList->currentMedia().canonicalUrl().path();

            sFullPath.remove(0,20);

            m_rTrackData.sTitle=sFullPath;

        }

        return m_rTrackData;

}


//Slots and signals to print Metadata
void tclApplicationUI::vConnectSignalsSlots()
{
    qDebug("Connecting slots");
    connect(m_tclPlayer->m_QPlayer, SIGNAL(mediaStatusChanged(QMediaPlayer::MediaStatus)), this, SLOT(vMetaDataChanged(QMediaPlayer::MediaStatus)));
}

void tclApplicationUI::vMetaDataChanged(QMediaPlayer::MediaStatus eStatus)
{
    qDebug() << eStatus;
    if(eStatus == QMediaPlayer::BufferedMedia)
    {
        trMetaData dets = rLoadMetaData();
        int length = dets.sTitle.length();
        if(length > 25)
        {
            dets.sTitle.chop(length - 25);
            dets.sTitle.append("...");
        }
        else if(length > 25)
        {
            dets.sAlbum.chop(length - 25);
            dets.sAlbum.append("...");
        }
        else if(length > 25)
        {
            dets.sArtist.chop(length - 25);
            dets.sArtist.append("...");
        }
        ui->metadisplay->setText( "Song name : " + dets.sTitle + "\n" + "Artist name : " + dets.sAlbum + "\n" + "Album name : " + dets.sArtist);
    }
}

void tclApplicationUI::onTimeOut()
{
    ui->TTS->setChecked(false);
}

