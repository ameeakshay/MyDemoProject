/********************************************************************************
** Form generated from reading UI file 'applicationui.ui'
**
** Created: Sat Sep 12 16:35:10 2015
**      by: Qt User Interface Compiler version 4.7.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_APPLICATIONUI_H
#define UI_APPLICATIONUI_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QListWidget>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QSlider>
#include <QtGui/QSpinBox>
#include <QtGui/QStatusBar>
#include <QtGui/QToolBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_tclApplicationUI
{
public:
    QWidget *centralWidget;
    QPushButton *play;
    QPushButton *repeat;
    QPushButton *next;
    QPushButton *prev;
    QPushButton *shuffle;
    QPushButton *stop;
    QPushButton *mute;
    QSlider *seekbar;
    QSlider *volumebar;
    QSpinBox *timer;
    QPushButton *TTS;
    QPushButton *info;
    QLabel *metadisplay;
    QPushButton *AllSongsListButton;
    QPushButton *AlbumButton;
    QPushButton *ArtistButton;
    QLabel *curTrackTime;
    QLabel *TotalTrackTime;
    QLabel *curTrackCount;
    QLabel *TotalTrackCount;
    QListWidget *playlistWidget;
    QLabel *label;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;
    QMenuBar *menuBar;

    void setupUi(QMainWindow *tclApplicationUI)
    {
        if (tclApplicationUI->objectName().isEmpty())
            tclApplicationUI->setObjectName(QString::fromUtf8("tclApplicationUI"));
        tclApplicationUI->resize(800, 480);
        tclApplicationUI->setStyleSheet(QString::fromUtf8(""));
        centralWidget = new QWidget(tclApplicationUI);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        play = new QPushButton(centralWidget);
        play->setObjectName(QString::fromUtf8("play"));
        play->setGeometry(QRect(370, 300, 71, 61));
#ifndef QT_NO_WHATSTHIS
        play->setWhatsThis(QString::fromUtf8("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/images/back.jpg\" /></p></body></html>"));
#endif // QT_NO_WHATSTHIS
        play->setStyleSheet(QString::fromUtf8(""));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/plat t.png"), QSize(), QIcon::Normal, QIcon::Off);
        icon.addFile(QString::fromUtf8(":/images/pauset.png"), QSize(), QIcon::Normal, QIcon::On);
        play->setIcon(icon);
        play->setIconSize(QSize(75, 75));
        play->setCheckable(true);
        repeat = new QPushButton(centralWidget);
        repeat->setObjectName(QString::fromUtf8("repeat"));
        repeat->setGeometry(QRect(190, 300, 71, 61));
#ifndef QT_NO_WHATSTHIS
        repeat->setWhatsThis(QString::fromUtf8("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/images/back.jpg\" /></p></body></html>"));
#endif // QT_NO_WHATSTHIS
        repeat->setStyleSheet(QString::fromUtf8(""));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/images/repeat_off t.png"), QSize(), QIcon::Normal, QIcon::Off);
        repeat->setIcon(icon1);
        repeat->setIconSize(QSize(60, 60));
        repeat->setCheckable(false);
        next = new QPushButton(centralWidget);
        next->setObjectName(QString::fromUtf8("next"));
        next->setGeometry(QRect(470, 300, 71, 61));
#ifndef QT_NO_WHATSTHIS
        next->setWhatsThis(QString::fromUtf8("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/images/back.jpg\" /></p></body></html>"));
#endif // QT_NO_WHATSTHIS
        next->setStyleSheet(QString::fromUtf8(";"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/images/next t.png"), QSize(), QIcon::Normal, QIcon::Off);
        next->setIcon(icon2);
        next->setIconSize(QSize(75, 75));
        next->setCheckable(false);
        prev = new QPushButton(centralWidget);
        prev->setObjectName(QString::fromUtf8("prev"));
        prev->setGeometry(QRect(280, 300, 71, 61));
#ifndef QT_NO_WHATSTHIS
        prev->setWhatsThis(QString::fromUtf8("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/images/back.jpg\" /></p></body></html>"));
#endif // QT_NO_WHATSTHIS
        prev->setStyleSheet(QString::fromUtf8(""));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/images/prev t.png"), QSize(), QIcon::Normal, QIcon::Off);
        prev->setIcon(icon3);
        prev->setIconSize(QSize(75, 75));
        prev->setCheckable(false);
        shuffle = new QPushButton(centralWidget);
        shuffle->setObjectName(QString::fromUtf8("shuffle"));
        shuffle->setGeometry(QRect(100, 300, 71, 61));
#ifndef QT_NO_WHATSTHIS
        shuffle->setWhatsThis(QString::fromUtf8("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/images/back.jpg\" /></p></body></html>"));
#endif // QT_NO_WHATSTHIS
        shuffle->setStyleSheet(QString::fromUtf8(""));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/images/shuffle off t.png"), QSize(), QIcon::Normal, QIcon::Off);
        icon4.addFile(QString::fromUtf8(":/images/shuffle t.png"), QSize(), QIcon::Normal, QIcon::On);
        shuffle->setIcon(icon4);
        shuffle->setIconSize(QSize(50, 50));
        shuffle->setCheckable(false);
        stop = new QPushButton(centralWidget);
        stop->setObjectName(QString::fromUtf8("stop"));
        stop->setGeometry(QRect(560, 300, 71, 61));
#ifndef QT_NO_WHATSTHIS
        stop->setWhatsThis(QString::fromUtf8("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/images/back.jpg\" /></p></body></html>"));
#endif // QT_NO_WHATSTHIS
        stop->setStyleSheet(QString::fromUtf8(""));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/images/stop t.png"), QSize(), QIcon::Normal, QIcon::Off);
        stop->setIcon(icon5);
        stop->setIconSize(QSize(75, 75));
        stop->setCheckable(false);
        mute = new QPushButton(centralWidget);
        mute->setObjectName(QString::fromUtf8("mute"));
        mute->setGeometry(QRect(710, 300, 71, 61));
#ifndef QT_NO_WHATSTHIS
        mute->setWhatsThis(QString::fromUtf8("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/images/back.jpg\" /></p></body></html>"));
#endif // QT_NO_WHATSTHIS
        mute->setStyleSheet(QString::fromUtf8(""));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/images/unmute.png"), QSize(), QIcon::Normal, QIcon::Off);
        icon6.addFile(QString::fromUtf8(":/images/mute.png"), QSize(), QIcon::Normal, QIcon::On);
        mute->setIcon(icon6);
        mute->setIconSize(QSize(60, 75));
        mute->setCheckable(false);
        seekbar = new QSlider(centralWidget);
        seekbar->setObjectName(QString::fromUtf8("seekbar"));
        seekbar->setGeometry(QRect(30, 270, 661, 29));
        seekbar->setStyleSheet(QString::fromUtf8("\n"
"QSlider::groove:horizontal {\n"
"    border: 1px solid #999999;\n"
"    height: 2px; /* the groove expands to the size of the slider by default. by giving it a height, it has a fixed size */\n"
"    background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #B1B1B1, stop:1 #c4c4c4);\n"
"    margin: 2px 0;\n"
"}\n"
"\n"
"QSlider::handle:horizontal {\n"
"    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #b4b4b4, stop:1 #8f8f8f);\n"
"    border: 3px solid #5c5c5c;\n"
"\n"
"    width: 12px;\n"
"    margin: -2px 0; /* handle is placed by default on the contents rect of the groove. Expand outside the groove */\n"
"    border-radius: 3px;\n"
"}\n"
"\n"
"QSlider::sub-page:horizontal {\n"
"    background: rgb(240,119,70);\n"
"}"));
        seekbar->setOrientation(Qt::Horizontal);
        volumebar = new QSlider(centralWidget);
        volumebar->setObjectName(QString::fromUtf8("volumebar"));
        volumebar->setGeometry(QRect(730, 100, 29, 181));
        volumebar->setStyleSheet(QString::fromUtf8(""));
        volumebar->setOrientation(Qt::Vertical);
        timer = new QSpinBox(centralWidget);
        timer->setObjectName(QString::fromUtf8("timer"));
        timer->setGeometry(QRect(610, 140, 71, 41));
        TTS = new QPushButton(centralWidget);
        TTS->setObjectName(QString::fromUtf8("TTS"));
        TTS->setGeometry(QRect(610, 80, 71, 61));
#ifndef QT_NO_WHATSTHIS
        TTS->setWhatsThis(QString::fromUtf8("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/images/back.jpg\" /></p></body></html>"));
#endif // QT_NO_WHATSTHIS
        TTS->setStyleSheet(QString::fromUtf8(""));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/images/tts.png"), QSize(), QIcon::Normal, QIcon::Off);
        icon7.addFile(QString::fromUtf8(":/images/clock_watch.png"), QSize(), QIcon::Normal, QIcon::On);
        TTS->setIcon(icon7);
        TTS->setIconSize(QSize(50, 75));
        TTS->setCheckable(true);
        info = new QPushButton(centralWidget);
        info->setObjectName(QString::fromUtf8("info"));
        info->setGeometry(QRect(610, 0, 171, 61));
#ifndef QT_NO_WHATSTHIS
        info->setWhatsThis(QString::fromUtf8("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/images/back.jpg\" /></p></body></html>"));
#endif // QT_NO_WHATSTHIS
        info->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        QIcon icon8;
        icon8.addFile(QString::fromUtf8(":/images/Capture.PNG"), QSize(), QIcon::Normal, QIcon::Off);
        info->setIcon(icon8);
        info->setIconSize(QSize(171, 61));
        info->setCheckable(true);
        metadisplay = new QLabel(centralWidget);
        metadisplay->setObjectName(QString::fromUtf8("metadisplay"));
        metadisplay->setGeometry(QRect(30, 370, 511, 61));
        AllSongsListButton = new QPushButton(centralWidget);
        AllSongsListButton->setObjectName(QString::fromUtf8("AllSongsListButton"));
        AllSongsListButton->setGeometry(QRect(30, 10, 131, 51));
#ifndef QT_NO_WHATSTHIS
        AllSongsListButton->setWhatsThis(QString::fromUtf8("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/images/back.jpg\" /></p></body></html>"));
#endif // QT_NO_WHATSTHIS
        AllSongsListButton->setStyleSheet(QString::fromUtf8(""));
        QIcon icon9;
        icon9.addFile(QString::fromUtf8(":/images/all songs.png"), QSize(), QIcon::Normal, QIcon::Off);
        AllSongsListButton->setIcon(icon9);
        AllSongsListButton->setIconSize(QSize(80, 42));
        AllSongsListButton->setCheckable(false);
        AlbumButton = new QPushButton(centralWidget);
        AlbumButton->setObjectName(QString::fromUtf8("AlbumButton"));
        AlbumButton->setGeometry(QRect(170, 10, 131, 51));
#ifndef QT_NO_WHATSTHIS
        AlbumButton->setWhatsThis(QString::fromUtf8("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/images/back.jpg\" /></p></body></html>"));
#endif // QT_NO_WHATSTHIS
        AlbumButton->setStyleSheet(QString::fromUtf8(""));
        QIcon icon10;
        icon10.addFile(QString::fromUtf8(":/images/album.png"), QSize(), QIcon::Normal, QIcon::Off);
        AlbumButton->setIcon(icon10);
        AlbumButton->setIconSize(QSize(79, 50));
        AlbumButton->setCheckable(false);
        ArtistButton = new QPushButton(centralWidget);
        ArtistButton->setObjectName(QString::fromUtf8("ArtistButton"));
        ArtistButton->setGeometry(QRect(310, 10, 141, 51));
#ifndef QT_NO_WHATSTHIS
        ArtistButton->setWhatsThis(QString::fromUtf8("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/images/back.jpg\" /></p></body></html>"));
#endif // QT_NO_WHATSTHIS
        ArtistButton->setStyleSheet(QString::fromUtf8(""));
        QIcon icon11;
        icon11.addFile(QString::fromUtf8(":/images/artist.png"), QSize(), QIcon::Normal, QIcon::Off);
        ArtistButton->setIcon(icon11);
        ArtistButton->setIconSize(QSize(75, 40));
        ArtistButton->setCheckable(false);
        curTrackTime = new QLabel(centralWidget);
        curTrackTime->setObjectName(QString::fromUtf8("curTrackTime"));
        curTrackTime->setGeometry(QRect(30, 260, 41, 21));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        curTrackTime->setFont(font);
        TotalTrackTime = new QLabel(centralWidget);
        TotalTrackTime->setObjectName(QString::fromUtf8("TotalTrackTime"));
        TotalTrackTime->setGeometry(QRect(640, 260, 41, 21));
        TotalTrackTime->setFont(font);
        curTrackCount = new QLabel(centralWidget);
        curTrackCount->setObjectName(QString::fromUtf8("curTrackCount"));
        curTrackCount->setGeometry(QRect(580, 210, 41, 41));
        QFont font1;
        font1.setPointSize(18);
        font1.setBold(true);
        font1.setWeight(75);
        curTrackCount->setFont(font1);
        TotalTrackCount = new QLabel(centralWidget);
        TotalTrackCount->setObjectName(QString::fromUtf8("TotalTrackCount"));
        TotalTrackCount->setGeometry(QRect(630, 210, 51, 41));
        TotalTrackCount->setFont(font1);
        playlistWidget = new QListWidget(centralWidget);
        playlistWidget->setObjectName(QString::fromUtf8("playlistWidget"));
        playlistWidget->setGeometry(QRect(30, 70, 531, 181));
        playlistWidget->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);"));
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(620, 210, 16, 41));
        label->setFont(font1);
        tclApplicationUI->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(tclApplicationUI);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        tclApplicationUI->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(tclApplicationUI);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        tclApplicationUI->setStatusBar(statusBar);
        menuBar = new QMenuBar(tclApplicationUI);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 800, 25));
        tclApplicationUI->setMenuBar(menuBar);

        retranslateUi(tclApplicationUI);

        QMetaObject::connectSlotsByName(tclApplicationUI);
    } // setupUi

    void retranslateUi(QMainWindow *tclApplicationUI)
    {
        tclApplicationUI->setWindowTitle(QApplication::translate("tclApplicationUI", "tclApplicationUI", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        play->setToolTip(QApplication::translate("tclApplicationUI", "Play / Pause ", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        play->setText(QString());
#ifndef QT_NO_TOOLTIP
        repeat->setToolTip(QApplication::translate("tclApplicationUI", "Repeat", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        repeat->setText(QString());
#ifndef QT_NO_TOOLTIP
        next->setToolTip(QApplication::translate("tclApplicationUI", "Next Song", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        next->setText(QString());
#ifndef QT_NO_TOOLTIP
        prev->setToolTip(QApplication::translate("tclApplicationUI", "Previous Song", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        prev->setText(QString());
#ifndef QT_NO_TOOLTIP
        shuffle->setToolTip(QApplication::translate("tclApplicationUI", "Shuffle", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        shuffle->setText(QString());
#ifndef QT_NO_TOOLTIP
        stop->setToolTip(QApplication::translate("tclApplicationUI", "Stop Song", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        stop->setText(QString());
#ifndef QT_NO_TOOLTIP
        mute->setToolTip(QApplication::translate("tclApplicationUI", "Mute / UnMute", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        mute->setText(QString());
#ifndef QT_NO_TOOLTIP
        TTS->setToolTip(QApplication::translate("tclApplicationUI", "time To Sleep !", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        TTS->setText(QString());
#ifndef QT_NO_TOOLTIP
        info->setToolTip(QApplication::translate("tclApplicationUI", "About Us", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        info->setText(QString());
        metadisplay->setText(QString());
#ifndef QT_NO_TOOLTIP
        AllSongsListButton->setToolTip(QApplication::translate("tclApplicationUI", "All Songs", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        AllSongsListButton->setText(QString());
#ifndef QT_NO_TOOLTIP
        AlbumButton->setToolTip(QApplication::translate("tclApplicationUI", "Album View", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        AlbumButton->setText(QString());
#ifndef QT_NO_TOOLTIP
        ArtistButton->setToolTip(QApplication::translate("tclApplicationUI", "Artist View", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        ArtistButton->setText(QString());
        curTrackTime->setText(QString());
        TotalTrackTime->setText(QString());
        curTrackCount->setText(QApplication::translate("tclApplicationUI", "1", 0, QApplication::UnicodeUTF8));
        TotalTrackCount->setText(QApplication::translate("tclApplicationUI", "22", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("tclApplicationUI", "/", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class tclApplicationUI: public Ui_tclApplicationUI {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_APPLICATIONUI_H
