#ifndef CATEGORIES_H
#define CATEGORIES_H
#include <QStringList>
#include <QString>
#include <QHash>

typedef struct
{
    QString sTitle;
    QString sArtist;
    QString sAlbum;
    float fTrackTime;
} trMetaData;

class tclCategories
{

private:
    QStringList oAllTracks;

    QMultiHash<QString, QString> oArtistHash;
    QMultiHash<QString, QString> oAlbumHash;

    QString m_sMusicDirPath;

    /* Get metadata from MP3 file name */
    trMetaData rGetMetaDataFromFile(QString sFile);


    /* Populate all tracks and categories */
    bool bPopulateAllTracksAndCategories();


public:
    tclCategories();
    QStringList sGetAllTracks();

    /* Get artist names */
    QStringList sGetArtistNames();

    /* Get album names */
    QStringList sGetAlbumNames();

    /*Get tracks for a particular album/artist*/
    QStringList sGetTracksForArtist(QString sArtists);
    QStringList sGetTracksForAlbum(QString sAlbums);

    /* Get MP3 files from directory */
    bool bGetFileNameFromDir(QString &sPath, QStringList &oFileList);


    // Test function for unit testing this class
    bool bPopulateCategories();
    bool bTestCategories();

};

#endif // CATEGORIES_H
