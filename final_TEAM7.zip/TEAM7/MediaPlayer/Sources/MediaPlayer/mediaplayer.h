#ifndef MEDIAPLAYER_H
#define MEDIAPLAYER_H

#include <QObject>
#include<QString>
#include<QMediaPlaylist>
#include<QMediaPlayer>
#include <QDebug>
#include "categories.h"

enum ePlayState{Playing,Paused,Stopped};

class tclMediaPlayer
{

  public:

    enum eRepeatState
    {
        eRepeatOFF, eRepeatOne, eRepeatAll
    };
    enum ePlayListState
    {
        eAllSongs, eArtists, eAlbums
    };

  ePlayState m_PlayState;
  /*int m_nTimer;
  bool m_bIsTimeSet;*/
  eRepeatState m_eRepeatState;
  ePlayListState m_eState;
  QMediaPlaylist *m_QMediaPlayList;
  QMediaPlayer *m_QPlayer;
  tclMediaPlayer();
  bool bInitMediaPlayer();



  //int nGetVolume();
  void vSetVolume(int);
  void vSetTimer(int);

  void vSelectTrack(int);

  //Tested
  void vSetPlayState();
  bool vAddTrackPlayList();
  void vNextTrack();
  void vPreviousTrack();
  void vStopTrack();
  void vSetShuffleMode();
  void vSetRepeatMode(eRepeatState);
  void vSetMute();
  QStringList sSelectAllSongs();
  QStringList sSelectAlbum();
  QStringList sSelectArtist();
  QStringList sSelectAlbumItem(QString);
  QStringList sSelectArtistItem(QString);
  void vConnectSignalsSlots();
  void vLoadPlayList(QStringList);
  bool bPopulateMediaPlayer();
  bool bTestMediaPlayer();


  private:


    tclCategories m_oCategory;
    int m_nVolume ;
    int m_nCurrentTrack;
    int m_nTotalTracks;
    long long int m_nTotalTrackTime;
    int m_nCurrentTrackTime;
    QString m_sCurrentAlbum;
    QString m_sTotalTrack;
    QString m_sTotalTrackTime;
    QString m_sCurrentTrackTime;
    bool m_bIsMuted;
    int m_nPlayListIndex;
    bool m_bShuffleMode;
    QString sHomeDir;




};
#endif
