/****************************************************************************
** Meta object code from reading C++ file 'applicationui.h'
**
** Created: Sat Sep 12 17:29:29 2015
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "applicationui.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'applicationui.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_tclApplicationUI[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      24,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      24,   18,   17,   17, 0x08,
      57,   49,   17,   17, 0x08,
      79,   49,   17,   17, 0x08,
     104,   49,   17,   17, 0x08,
     126,   17,   17,   17, 0x08,
     146,   17,   17,   17, 0x08,
     170,  164,   17,   17, 0x08,
     201,   17,   17,   17, 0x08,
     219,   17,   17,   17, 0x08,
     237,   17,   17,   17, 0x08,
     255,   49,   17,   17, 0x08,
     281,  276,   17,   17, 0x08,
     308,  164,   17,   17, 0x08,
     340,   17,   17,   17, 0x08,
     372,   17,   17,   17, 0x08,
     397,   17,   17,   17, 0x08,
     428,  423,   17,   17, 0x08,
     476,   17,   17,   17, 0x08,
     502,   17,   17,   17, 0x08,
     536,  527,   17,   17, 0x08,
     556,   17,   17,   17, 0x08,
     566,   17,   17,   17, 0x08,
     578,   17,   17,   17, 0x08,
     610,  602,   17,   17, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_tclApplicationUI[] = {
    "tclApplicationUI\0\0event\0"
    "closeEvent(QCloseEvent*)\0checked\0"
    "on_play_toggled(bool)\0on_shuffle_toggled(bool)\0"
    "on_mute_toggled(bool)\0on_repeat_clicked()\0"
    "on_info_pressed()\0value\0"
    "on_volumebar_valueChanged(int)\0"
    "on_stop_clicked()\0on_next_clicked()\0"
    "on_prev_clicked()\0on_TTS_toggled(bool)\0"
    "arg1\0on_timer_valueChanged(int)\0"
    "on_seekbar_valueChanged(qint64)\0"
    "on_AllSongsListButton_clicked()\0"
    "on_AlbumButton_clicked()\0"
    "on_ArtistButton_clicked()\0item\0"
    "on_playlistWidget_itemClicked(QListWidgetItem*)\0"
    "ondurationchanged(qint64)\0"
    "onpostionchanged(qint64)\0position\0"
    "onseekbarMoved(int)\0onClose()\0onTimeOut()\0"
    "onMediaContentChanged()\0eStatus\0"
    "vMetaDataChanged(QMediaPlayer::MediaStatus)\0"
};

const QMetaObject tclApplicationUI::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_tclApplicationUI,
      qt_meta_data_tclApplicationUI, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &tclApplicationUI::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *tclApplicationUI::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *tclApplicationUI::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_tclApplicationUI))
        return static_cast<void*>(const_cast< tclApplicationUI*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int tclApplicationUI::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: closeEvent((*reinterpret_cast< QCloseEvent*(*)>(_a[1]))); break;
        case 1: on_play_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: on_shuffle_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: on_mute_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: on_repeat_clicked(); break;
        case 5: on_info_pressed(); break;
        case 6: on_volumebar_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: on_stop_clicked(); break;
        case 8: on_next_clicked(); break;
        case 9: on_prev_clicked(); break;
        case 10: on_TTS_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 11: on_timer_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: on_seekbar_valueChanged((*reinterpret_cast< qint64(*)>(_a[1]))); break;
        case 13: on_AllSongsListButton_clicked(); break;
        case 14: on_AlbumButton_clicked(); break;
        case 15: on_ArtistButton_clicked(); break;
        case 16: on_playlistWidget_itemClicked((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 17: ondurationchanged((*reinterpret_cast< qint64(*)>(_a[1]))); break;
        case 18: onpostionchanged((*reinterpret_cast< qint64(*)>(_a[1]))); break;
        case 19: onseekbarMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: onClose(); break;
        case 21: onTimeOut(); break;
        case 22: onMediaContentChanged(); break;
        case 23: vMetaDataChanged((*reinterpret_cast< QMediaPlayer::MediaStatus(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 24;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
