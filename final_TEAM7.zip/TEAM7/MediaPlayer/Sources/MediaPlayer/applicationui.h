#ifndef APPLICATIONUI_H
#define APPLICATIONUI_H

#include <QMainWindow>
#include <QDebug>
#include <QMessageBox>
#include <QCloseEvent>
#include <QListWidget>
#include "mediaplayer.h"

namespace Ui {
    class tclApplicationUI;
}

class tclApplicationUI : public QMainWindow
{
    Q_OBJECT

public:
    explicit tclApplicationUI(QWidget *parent = 0);
    ~tclApplicationUI();
    enum ePlaylistState
    {
        allSongs, albums, artists, allArtistSongs, allAlbumSongs

    };

    trMetaData rLoadMetaData();

private slots:

     void closeEvent(QCloseEvent *event);
    void on_play_toggled(bool checked);



    void on_shuffle_toggled(bool checked);

    void on_mute_toggled(bool checked);

    void on_repeat_clicked();

    void on_info_pressed();

    void on_volumebar_valueChanged(int value);

    void on_stop_clicked();

    void on_next_clicked();

    void on_prev_clicked();

    void on_TTS_toggled(bool checked);

    void on_timer_valueChanged(int arg1);

    void on_seekbar_valueChanged(qint64 value);

    void on_AllSongsListButton_clicked();

    void on_AlbumButton_clicked();

    void on_ArtistButton_clicked();


    //void on_playlistWidget_currentRowChanged(int currentRow);


    void on_playlistWidget_itemClicked(QListWidgetItem *item);

    void ondurationchanged(qint64);

    void onpostionchanged(qint64);

    void onseekbarMoved(int position);

    void onClose();

    void onTimeOut();

    void onMediaContentChanged();

    void vMetaDataChanged(QMediaPlayer::MediaStatus eStatus);

private:
    Ui::tclApplicationUI *ui;
    tclMediaPlayer *m_tclPlayer;
    tclMediaPlayer::eRepeatState eStatus;
    bool bState;
    ePlaylistState eListState;
    QString m_artist, m_album;
    QTimer *m_qTimer;
    int m_nTotalTracks, m_nCurrentTrackIndex;
    qint64 m_nTotalTrackTime;
    bool bSongClicked;
    void vConnectSignalsSlots();
    void vDispTrack();
};

#endif // APPLICATIONUI_H
