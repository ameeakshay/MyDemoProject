#include "categories.h"
#include<QDir>
#include<QDebug>
#include<QMediaPlayer>
#include<QMediaPlaylist>
#include<fstream>
#include<iostream>
#include "string"
#include<QHash>
#include <QMultiHash>

using namespace  std;



tclCategories::tclCategories()
{
    QString sHomeDir = QDir::homePath();
    // Set the music directory path
    m_sMusicDirPath = sHomeDir + QDir::separator() + "Music";
    bool result=bGetFileNameFromDir(m_sMusicDirPath,oAllTracks);
    bool res=bPopulateAllTracksAndCategories();

}

/*Test cases*/
bool tclCategories::bPopulateCategories()
{
    QStringList sTrackList;
    bool result=false;

    // Test bGetFileNameFromDir
    result=bGetFileNameFromDir(m_sMusicDirPath,oAllTracks);

    // Test rGetMetaDataFromFile
    QString sFile;
    trMetaData data;

    foreach(sFile,oAllTracks)
    {
       data = rGetMetaDataFromFile(sFile);
        qDebug()<<data.sAlbum;
        qDebug()<<data.sArtist;
    }

    // Test bPopulateAllTracksAndCategories
    result=bPopulateAllTracksAndCategories();

    // Test sGetAllTracks and related functions
    QStringList sAllsongs= sGetAllTracks();

    QStringList sArtists= sGetArtistNames();


    QStringList sAlbums= sGetAlbumNames();

    // Test get tracks from category item
    QString sArtistName = "Siddharth Menon";
    sTrackList = sGetTracksForArtist(sArtistName);

    QString sAlbumName = "Chennai Express";
    sTrackList = sGetTracksForAlbum(sAlbumName);
    return result;

}


/*To get files from the directory*/
bool tclCategories::bGetFileNameFromDir(QString &sPath, QStringList &oFileList)
{
    QDir directory(sPath);
    QStringList filters;

    filters << "*.mp3";

    directory.setNameFilters(filters);

    oFileList = directory.entryList();

    if(oFileList.empty())
    {
        return  false;
    }

    else
    {
        return true;
    }
}


/*To create the structure*/
trMetaData tclCategories::rGetMetaDataFromFile(QString sFile)
{
        QString filepath = m_sMusicDirPath ;
        filepath.append('/');
        filepath.append(sFile);
        //qDebug()<<filepath;
        std::string Path;
        Path = filepath.toStdString();
        ifstream mp3In;

        trMetaData rData;
        //qDebug()<<sFile;

        char sArtistString[31] = {'\0'};
        char sAlbumString[31] = {'\0'};
        char sTag[4]={'0'};

        // Validate whether the file has ID3v1 metadata by comparing TAG
        mp3In.open(Path.c_str(), ios::binary);

        mp3In.seekg(-128, ios::end);

        mp3In.read(sTag, 3);

        if(strcmp(sTag,"TAG"))
        {
            qDebug()<<sTag;
            rData.sAlbum="Unknown Album";
            rData.sArtist="Unknown Artist";
        }
        else
        {
            mp3In.seekg(-95, ios::end);

            mp3In.read(sArtistString, 30);
            rData.sArtist.append(sArtistString);

            if(rData.sArtist.isEmpty()||rData.sArtist.isNull())
            {
                 rData.sArtist="Unknown Artist";
            }

            mp3In.read(sAlbumString, 30);
            rData.sAlbum.append(sAlbumString);

            if(rData.sAlbum.isEmpty()||rData.sArtist.isNull())
            {
                 rData.sAlbum="Unknown Album";
            }
        }

        mp3In.close();
        return rData;

}


bool tclCategories::bPopulateAllTracksAndCategories()
{
    QString sTrackName;
    trMetaData rData;

    foreach(sTrackName,oAllTracks)
    {
      rData= rGetMetaDataFromFile(sTrackName);

      oArtistHash.insert(rData.sArtist,sTrackName);
      oAlbumHash.insert(rData.sAlbum,sTrackName);

    }

    if (oArtistHash.isEmpty())
        qDebug()<< "is empty";
    else
        return true;

}


QStringList tclCategories::sGetArtistNames()
{

    QStringList artistnames=oArtistHash.uniqueKeys();

    return artistnames;
}

QStringList tclCategories::sGetAlbumNames()
{

    QStringList albumnames=oAlbumHash.uniqueKeys();
    return albumnames;
}

QStringList tclCategories::sGetAllTracks()
{
    return oAllTracks;
}

QStringList tclCategories::sGetTracksForArtist(QString sArtists)
{
    return(oArtistHash.values(sArtists));
}

QStringList tclCategories::sGetTracksForAlbum(QString sAlbums)
{
    return(oAlbumHash.values(sAlbums));
}










