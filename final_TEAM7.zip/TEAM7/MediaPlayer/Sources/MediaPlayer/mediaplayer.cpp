#include "mediaplayer.h"
#include <QTime>
#include <QMediaPlaylist>
#include<QMediaPlayer>
#include <QMessageBox>
#include<QDebug>
#include<QTimer>
#include <QDir>
#include<iostream>

tclMediaPlayer::tclMediaPlayer()
{

   bInitMediaPlayer();

}



bool tclMediaPlayer::bInitMediaPlayer()
{
     m_QMediaPlayList=new QMediaPlaylist;
     m_QPlayer=new QMediaPlayer;
     vAddTrackPlayList();
     m_PlayState= Paused;

     m_QPlayer->setVolume(40);

     sHomeDir = QDir::homePath() + QDir::separator() + "Music";

     m_nTotalTracks = m_QMediaPlayList->mediaCount();
     m_nTotalTrackTime = m_QPlayer->duration();

     m_bIsMuted=false;

     m_bShuffleMode=false;

     m_eRepeatState=eRepeatOFF;

    //m_QMediaPlayList->setCurrentIndex(0);
    m_QPlayer->setPlaylist(m_QMediaPlayList);
    return true;
}



//To mute
void tclMediaPlayer::vSetMute()
{
    m_bIsMuted= m_QPlayer->isMuted();
    if(m_bIsMuted)
    {
        m_bIsMuted = false;

    }
    else
    {
        m_bIsMuted = true;

    }
    m_QPlayer->setMuted(m_bIsMuted);
}


//Play/Pause
void tclMediaPlayer::vSetPlayState()
{
    if(m_PlayState == Playing)
    {
         m_PlayState = Paused;
         m_QPlayer->pause();
    }
    else
    {
        m_PlayState = Playing;
        m_QPlayer->play();

    }

}

//Select track
void tclMediaPlayer::vSelectTrack(int iIndex)
{
    m_QMediaPlayList->setCurrentIndex(iIndex);
    m_QPlayer->play();
}

//Shuffle mode
void tclMediaPlayer::vSetShuffleMode()
{
    if(m_bShuffleMode)
    {
        m_bShuffleMode=false;
    }
    else
    {
        m_bShuffleMode=true;
        m_QMediaPlayList->setPlaybackMode(QMediaPlaylist::Random);

        if(m_eRepeatState== eRepeatOne)
        {
            m_eRepeatState=eRepeatOFF;
        }

    }
}


//Repeat mode
void tclMediaPlayer::vSetRepeatMode(eRepeatState RepeatState)
{
    if(RepeatState==eRepeatOFF)
    {
        if(m_bShuffleMode)
        {
            m_bShuffleMode = false;
        }
        m_QMediaPlayList->setPlaybackMode(QMediaPlaylist::Sequential);
    }
    else if(RepeatState == eRepeatOne)
    {
        m_QMediaPlayList->setPlaybackMode(QMediaPlaylist::CurrentItemInLoop);
    }
    else
    {
        m_QMediaPlayList->setPlaybackMode(QMediaPlaylist::Loop);
    }
    m_eRepeatState = RepeatState;

}

//Stop track
void tclMediaPlayer::vStopTrack()
{
    m_PlayState=Stopped;
    m_QPlayer->stop();
}

//Next track
void tclMediaPlayer::vNextTrack()
{
    if(m_bShuffleMode==true)
    {
        m_QMediaPlayList->setPlaybackMode(QMediaPlaylist::Random);
        m_QMediaPlayList->next();
    }
    else if(m_eRepeatState==eRepeatOFF)
    {  

            m_QMediaPlayList->setPlaybackMode(QMediaPlaylist::Sequential);
            m_QMediaPlayList->next();

    }
    else if(m_eRepeatState==eRepeatAll)
    {
        m_QMediaPlayList->setPlaybackMode(QMediaPlaylist::Loop);
        m_QMediaPlayList->next();
    }
    else
    {
        m_QMediaPlayList->setPlaybackMode(QMediaPlaylist::Sequential);
        m_QMediaPlayList->next();
        m_QMediaPlayList->setPlaybackMode(QMediaPlaylist::CurrentItemInLoop);
    }

}

//Previous track
void tclMediaPlayer::vPreviousTrack()
{
    if(m_bShuffleMode==true)
    {
        m_QMediaPlayList->setPlaybackMode(QMediaPlaylist::Random);
        m_QMediaPlayList->previous();
    }
    else if(m_eRepeatState==eRepeatOFF)
    {
        m_QMediaPlayList->setPlaybackMode(QMediaPlaylist::Sequential);
        m_QMediaPlayList->previous();
    }
    else if(m_eRepeatState==eRepeatAll)
    {
        m_QMediaPlayList->setPlaybackMode(QMediaPlaylist::Loop);
        m_QMediaPlayList->previous();
    }
    else
    {
        m_QMediaPlayList->setPlaybackMode(QMediaPlaylist::Sequential);
        m_QMediaPlayList->previous();
        m_QMediaPlayList->setPlaybackMode(QMediaPlaylist::CurrentItemInLoop);
    }

}

//clicking on the button All songs
QStringList tclMediaPlayer::sSelectAllSongs()
{
    QStringList sAllTracks = m_oCategory.sGetAllTracks();
    return sAllTracks;
}

//Clicking on the button "ARTIST"
QStringList tclMediaPlayer::sSelectArtist()
{
QStringList sArtistNames = m_oCategory.sGetArtistNames();
return sArtistNames;
}

//Clicking on the button "ALBUM"
QStringList tclMediaPlayer::sSelectAlbum()
{
QStringList sAlbumNames = m_oCategory.sGetAlbumNames();
return sAlbumNames;
}

//Selecting a particular Album
QStringList tclMediaPlayer::sSelectAlbumItem(QString sAlbumName)
{
    QStringList sAlbumTrackNames = m_oCategory.sGetTracksForAlbum(sAlbumName);
    return sAlbumTrackNames;
}

//Selecting a particular artist
QStringList tclMediaPlayer::sSelectArtistItem(QString sArtistName)
{
    QStringList sArtistTrackNames = m_oCategory.sGetTracksForArtist(sArtistName);
    return sArtistTrackNames;
}


//Adding track to playlist
bool tclMediaPlayer::vAddTrackPlayList()
{

    QString sFile;
    QStringList sFileList;
    bool res= m_oCategory.bGetFileNameFromDir(sHomeDir,sFileList);

    foreach(sFile,sFileList)
    {

        QString absPath=sHomeDir+"/"+ sFile;

        m_QMediaPlayList->addMedia(QUrl::fromLocalFile(absPath));

    }

    return res;
}





bool tclMediaPlayer::bPopulateMediaPlayer()
{

    bool result = vAddTrackPlayList();

    bInitMediaPlayer();
    //qDebug()<< m_oCategory.sGetAllTracks();

    return result;
}

void tclMediaPlayer::vSetVolume(int value)
{
    m_QPlayer->setVolume(value);
}

void tclMediaPlayer::vLoadPlayList(QStringList sSongList)
{
    QString sFile;
    m_QMediaPlayList->clear();
    foreach(sFile,sSongList)
        {

            QString absPath=sHomeDir+"/"+ sFile;
            //qDebug()<< absPath;
            m_QMediaPlayList->addMedia(QUrl::fromLocalFile(absPath));
        }
}



